
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import DashboardHome from './pages/DashboardHome';
import Orders from './pages/Orders';
import ClinicManager from './pages/ClinicManager';
import Appointments from './pages/Appointments';
import ProfileSettings from './pages/ProfileSettings';
import { Clinic, Order, Appointment, DoctorProfile, TimeSlot } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isBookingEnabled, setIsBookingEnabled] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const [doctorProfile, setDoctorProfile] = useState<DoctorProfile>({
    name: 'د. سارة جينكنز',
    title: 'استشاري جراحة العظام والمفاصل',
    specialty: 'دكتوراة جراحة العظام - جامعة لندن الملكية',
    bio: 'أكثر من 15 عاماً من الخبرة في جراحات المناظير وإصابات الملاعب وتغيير المفاصل.',
    photo: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300&h=300'
  });

  const [clinics, setClinics] = useState<Clinic[]>([
    { 
      id: '1', 
      name: 'عيادة الأمل (القاهرة)', 
      address: 'شارع التحرير، الدقي', 
      consultationFee: 350, 
      workingHours: '4م - 10م', 
      currentServingNumber: 2,
      maxPatientsPerDay: 30,
      isClosedToday: false,
      photo: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=400&h=200',
      mapLink: 'https://maps.google.com'
    },
    { 
      id: '2', 
      name: 'عيادة الشروق (الجيزة)', 
      address: 'فيصل، الجيزة', 
      consultationFee: 250, 
      workingHours: '10ص - 2ظ', 
      currentServingNumber: 0,
      maxPatientsPerDay: 15,
      isClosedToday: false,
      photo: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=400&h=200',
      mapLink: 'https://maps.google.com'
    },
  ]);
  
  const [selectedClinicId, setSelectedClinicId] = useState<string>(clinics[0].id);

  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([
    { id: 'ts1', clinicId: '1', day: 'الأحد', startTime: '16:00', endTime: '22:00', duration: 30, type: 'كشف', capacity: 12, bookedCount: 5 },
    { id: 'ts2', clinicId: '1', day: 'الاثنين', startTime: '16:00', endTime: '22:00', duration: 30, type: 'استشارة', capacity: 10, bookedCount: 2 },
    { id: 'ts3', clinicId: '2', day: 'السبت', startTime: '10:00', endTime: '14:00', duration: 20, type: 'كشف', capacity: 12, bookedCount: 0 },
  ]);

  const [orders, setOrders] = useState<Order[]>([
    { id: 'o1', clinicId: '1', slotId: 'ts2', patientName: 'أحمد محمود', phoneNumber: '01012345678', queueNumber: 1, type: 'كشف', status: 'تم الكشف', paymentStatus: 'تم دفع الرسوم', date: today, notes: 'صداع', consultationFee: 350, serviceFee: 15 },
    { id: 'o2', clinicId: '1', slotId: 'ts1', patientName: 'سارة خالد', phoneNumber: '01112345678', queueNumber: 2, type: 'استشارة', status: 'منتظر', paymentStatus: 'لم يتم الدفع', date: today, notes: 'متابعة', consultationFee: 350, serviceFee: 15 },
    { id: 'o3', clinicId: '2', slotId: 'ts3', patientName: 'ياسين علي', phoneNumber: '01212345678', queueNumber: 1, type: 'كشف', status: 'منتظر', paymentStatus: 'تم دفع الرسوم', date: yesterday, notes: 'كشف نظر', consultationFee: 250, serviceFee: 15 },
  ]);

  const activeClinic = clinics.find(c => c.id === selectedClinicId) || clinics[0];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <DashboardHome clinics={clinics} selectedClinicId={selectedClinicId} setSelectedClinicId={setSelectedClinicId} orders={orders} />;
      case 'orders': return <Orders orders={orders} setOrders={setOrders} selectedClinicId={selectedClinicId} clinics={clinics} setClinics={setClinics} doctorName={doctorProfile.name} timeSlots={timeSlots} setTimeSlots={setTimeSlots} />;
      case 'clinics': return <ClinicManager clinics={clinics} setClinics={setClinics} />;
      case 'schedule': return <Appointments selectedClinicId={selectedClinicId} clinics={clinics} setClinics={setClinics} timeSlots={timeSlots} setTimeSlots={setTimeSlots} />;
      case 'profile': return <ProfileSettings profile={doctorProfile} setProfile={setDoctorProfile} />;
      default: return <DashboardHome clinics={clinics} selectedClinicId={selectedClinicId} setSelectedClinicId={setSelectedClinicId} orders={orders} />;
    }
  };

  return (
    <div className="min-h-screen flex bg-[#f8fafc] text-right font-['Cairo'] relative">
      <Sidebar 
        currentTab={activeTab} 
        setTab={(tab) => { setActiveTab(tab); setIsSidebarOpen(false); }} 
        clinics={clinics} 
        selectedClinicId={selectedClinicId} 
        setSelectedClinicId={setSelectedClinicId} 
        doctorProfile={doctorProfile}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      <main className="flex-1 lg:mr-64 w-full p-4 md:p-8 lg:p-12 transition-all duration-300">
        <header className="mb-6 md:mb-10 flex justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-600 bg-white rounded-xl border border-slate-100 shadow-sm"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <h2 className="text-lg md:text-xl font-bold text-[#0f172a] truncate max-w-[150px] md:max-w-none">
              {activeTab === 'dashboard' ? 'الإحصائيات والتحليلات' : 
               activeTab === 'orders' ? 'إدارة الطابور والدور' : 
               activeTab === 'clinics' ? 'إدارة عياداتي وفروعي' : 
               activeTab === 'profile' ? 'الملف الشخصي للطبيب' : 'تنظيم المواعيد والجدول'}
            </h2>
          </div>
          
          <div className="flex items-center gap-2 md:gap-6">
            <div className="hidden sm:flex items-center gap-4 border-l border-slate-200 pl-6 ml-6">
               <div className="flex items-center gap-3">
                  <span className={`text-[10px] font-bold uppercase tracking-wider ${isBookingEnabled ? 'text-emerald-500' : 'text-slate-400'}`}>
                    {isBookingEnabled ? 'الحجز متاح' : 'معلق'}
                  </span>
                  <button 
                    onClick={() => setIsBookingEnabled(!isBookingEnabled)}
                    className={`w-10 h-5 rounded-full p-1 transition-all relative ${isBookingEnabled ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`w-3 h-3 bg-white rounded-full shadow-sm transform transition-transform ${isBookingEnabled ? 'translate-x-[-1.25rem]' : 'translate-x-0'}`}></div>
                  </button>
               </div>
            </div>

            <div 
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-3 bg-white p-1 md:p-1.5 md:pl-4 rounded-2xl shadow-sm border border-slate-100 cursor-pointer hover:bg-slate-50 transition-all"
            >
              <div className="hidden md:block text-left">
                <p className="text-sm font-bold text-slate-800 leading-none">{doctorProfile.name}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-tighter">{doctorProfile.title}</p>
              </div>
              <img src={doctorProfile.photo} className="w-8 h-8 md:w-10 md:h-10 rounded-xl object-cover bg-slate-100" alt="Profile" />
            </div>
          </div>
        </header>

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {(!isBookingEnabled || activeClinic.isClosedToday) && (
            <div className={`mb-6 p-4 rounded-2xl text-xs md:text-sm font-bold flex items-center gap-3 border ${activeClinic.isClosedToday ? 'bg-rose-50 border-rose-200 text-rose-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
               <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
               <p>
                {activeClinic.isClosedToday ? 
                  `تنبيه: عيادة "${activeClinic.name}" مغلقة حالياً.` : 
                  `تنبيه: تم إيقاف الحجز في جميع العيادات.`
                }
               </p>
            </div>
          )}
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;
